#pragma once

#define ASSET_PATH "assets\\"
#define WINDOW_WIDTH 1200
#define WINDOW_HEIGHT 600
#define CANVAS_WIDTH 1000
#define CANVAS_HEIGHT 500
#define OBSTACLE_ROWS 4
#define OBSTACLES_PER_ROW 30
#define BALL_MOVEMENT 15.0f
#define INFOTEXT_SIZE 30
#define INFOTEXT_POSX 30
#define INFOTEXT_POSY 40