#pragma once

struct Disk {
	float cx, cy;
	float radius;
};